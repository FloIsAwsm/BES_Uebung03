/**
 * @file commons.c
 * Betriebsysteme Beispiel 3 - common library for maintaining semaphores and a shared memory (ring buffer).
 *
 * @author Stammgruppe 7
 * @author Matthias Heger-Koenig <matthias.hegerkoenig@technikum-wien.at> Matrikelnummer: 0910258029
 * @author Sebastian Vogel       <sebastian.vogel@technikum-wien.at>      Matrikelnummer: 0910258067
 * @author Juergen Zornig        <juergen.zornig@technikum-wien.at>       Matrikelnummer: 0910258047
 * @date 2010/05/10
 *
 * @version $Revision: 32 $
 *
 * @todo nothing todo.
 *
 * URL: $HeadURL$
 *
 * Last Modified: $Author: sebastian $
 */

/*
 * -------------------------------------------------------------- includes --
 */
 
#include <stdio.h>
#include <stdlib.h> /* for strtol() */
#include <limits.h> /* for strtol() */
#include <string.h> /* for strerror() */
#include <errno.h>
#include <unistd.h> /* for getopt() */
#include <getopt.h> /* for getopt() */
#include <sem182.h> /* Seamphore-Library */
#include <sys/types.h> 
#include <sys/shm.h>
#include <sys/ipc.h>


#include "commons.h"


/*
 * --------------------------------------------------------------- defines --
 */


/*
 * Key for shared memory and semaphores (Matrikelnummer (without the first 2 digits) * 10 and a number from 0-9 at the end)
 */

#define SEM_KEY_WRITE 1025806700

#define SEM_KEY_READ 1025806701

#define SHM_KEY 1025806702


#define PERMISSIONS 0660


/*
 * --------------------------------------------------------------- globals --
 */
const char *szCommand = "Not yet set";

int shmID = 0;
int semID_read = 0;
int semID_write = 0;

int *pnShm = NULL;


/*
 * -------------------------------------------------------------- functions --
 */

/**
 *@brief rmRessources
 *
 * Removes all allocated ressources
 *
 * \param mode
 *
 * \return void
 */
void rmRessources(int mode)
{
	
	if (pnShm != NULL)
	{
		if (shmdt(pnShm) == -1)
		{
			printError("Could not detach shared memory from pointer");
		}
		pnShm = NULL;
	}

	if ((mode == EMPFAENGER) || (mode == ERROR))
	{
		if (semID_write != 0)
		{
			semrm(semID_write);
			semID_write = 0;
		}

		if (semID_read != 0)
		{
			semrm(semID_read);
			semID_read = 0;
		}

		if(shmID != 0)
		{
			if (shmctl(shmID, IPC_RMID, NULL) == -1)
			{
				/* TODO: error */
				printError("Could not remove shared memory");
			}
			shmID = 0;
		}
	}
}


/**
 *@brief getShmID
 *
 * Initiates a new Shared Memory with Size shmSize * sizeof(char) and returns its ID, 
 * when Shared Memory with KEY already exist it grabs the Shared Memory and returns its ID
 *
 * \param shmSize Size of the Shared Memory
 * \param permFlag SHM_RDONLY if shared memory should be attached read only, 0 for read/write perm.
 *
 * \return int*
 * \retval pointer on shared Memory
 * \retval NULL on error
 */
int *getShm(int shmSize, int permFlag)
{
	if (shmID != 0 || pnShm != NULL)
		return NULL;

	if ((shmID = shmget(SHM_KEY, shmSize, PERMISSIONS|IPC_CREAT|IPC_EXCL)) == -1)
	{
		if (errno == EEXIST )
		{
			if ((shmID = shmget(SHM_KEY, shmSize, PERMISSIONS)) == -1)
			{
				shmID = 0;
				return NULL;
			}
				
		}
		else
		{
			shmID = 0;
			return NULL;
		}
	}

	if ((pnShm = shmat(shmID, NULL, permFlag)) == 	(int *) -1)
	{
		pnShm = NULL;
		return NULL;
	}

	return pnShm;	

}

/**
 *@brief getWriteSemID
 *
 * Initiates a new Semaphore with Size semSize and returns its ID, 
 * when Semaphore with KEY already exist it grabs the Semaphore and returns its ID
 *
 * \param semSize Size of the Semaphore 
 *
 * \return int
 * \retval Semaphore ID
 */
int getWriteSemID(int semSize)
{
	if( semID_write != 0)
		return ERROR;

	if ((semID_write = seminit(SEM_KEY_WRITE, PERMISSIONS, semSize)) == -1)
	{
		if (errno == EEXIST)
		{
			if ((semID_write = semgrab(SEM_KEY_WRITE)) == -1)
			{
				semID_write = 0;
				return ERROR;
			}
		}
		else
		{
			semID_write = 0;
			return ERROR;
		}

	}

	return semID_write;
}

/**
 *@brief getReadSemID
 *
 * Initiates a new Semaphore with Size semSize and returns its ID, 
 * when Semaphore with KEY already exist it grabs the Shared Memory and returns its ID
 *
 * \param semSize Size of the Semaphore 
 *
 * \return int
 * \retval Semaphore ID
 */
int getReadSemID(int semSize)
{

	if( semID_read != 0)
		return ERROR;

	if ((semID_read = seminit(SEM_KEY_READ, PERMISSIONS, semSize)) == -1)
	{
		if (errno == EEXIST)
		{
			if ((semID_read = semgrab(SEM_KEY_READ)) == -1)
			{
				semID_read = 0;
				return ERROR;
			}
		}
		else
		{
			semID_read = 0;
			return ERROR;
		}

	}

	return semID_read;
}

/**
 *@brief getSemSize
 *
 * recieves argc and argv[] and returns the size of the Semaphore (ringpuffer) memory as entered by the user
 *
 * \param argc Argument count 
 * \param argv[] Array of Arguments
 *
 * \return int
 * \retval -1 on error or if size < 1
 * \retval <0 Size of Semaphore (ringpuffer) memory
 */
int getSemSize(int argc, char * const argv[])
{
	int c = 0;
	long int semSize;
	char *optValue = NULL;

	if (argc > 3)
		return ERROR;

	/* if opterr == 0 getopt() does not print errors to stderr */
	opterr = 0;
	
	/* Parse Arguments - on error: return ERROR */
	while ((c = getopt (argc, argv, "m:")) != -1)
		switch (c)
		{
			case 'm':
				optValue = optarg;
				break;
			case '?':
				return ERROR;
			default:
				return ERROR;
		}

	/* if Argument "m" was not found opValue is empty => return ERROR */
	if (optValue == NULL)
		return ERROR;

	
	/* Convert argument string to int */
	errno = 0;
	semSize = strtol(optValue, NULL, 10);

	/* return Error if strtol fails or semSize < 1 */
	if ((errno == ERANGE && (semSize == LONG_MAX || semSize == LONG_MIN))
				|| semSize < 1) 
			return ERROR;

	return semSize;

}

/**
 *@brief printError
 *
 * recieves errno and prints details
 *
 * \param szMessage additional error message to print
 *
 * \return void
 * \retval void 
 */
void printError(const char *szMessage)
{
	if (errno != 0)
	{
		(void) fprintf(stderr, "%s: %s - %s\n", szCommand, szMessage, strerror(errno));
	}
	else
	{
		(void) fprintf(stderr, "%s: %s\n", szCommand, szMessage);
	}
}




/*
 * =================================================================== eof ==
 */

