/**
 * @file sender.c
 * Betriebsysteme Beispiel 3 - shared memory and semaphore sender program. When it is executed, it waits for character data from STDIN and writes it
 * to a shared ringbuffer memory which size is declared by the command parameter '-m'. If the shared memory doesn�t exist, it is created automagically ;)
 *
 * @author Stammgruppe 7
 * @author Matthias Heger-Koenig <matthias.hegerkoenig@technikum-wien.at> Matrikelnummer: 0910258029
 * @author Sebastian Vogel       <sebastian.vogel@technikum-wien.at>      Matrikelnummer: 0910258067
 * @author Juergen Zornig        <juergen.zornig@technikum-wien.at>       Matrikelnummer: 0910258047
 * @date 2010/05/10
 *
 * @version $Revision: 32 $
 *
 * @todo nothing to do.
 *
 * URL: $HeadURL$
 *
 * Last Modified: $Author: sebastian $
 */

/*
 * -------------------------------------------------------------- includes --
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sem182.h> 

#include "commons.h"

/*
 * -------------------------------------------------------------- functions --
 */

/**
 *
 * \brief sender main
 *
 * This is the main entry point for the sender process.
 *
 * \param argc the number of arguments
 * \param argv the arguments itselves (including the program name in argv[0])
 *
 * @return    exit status of program
 * @retval    EXIT_FAILURE	Program terminated due to a failure
 * @retval    EXIT_SUCCESS	Program terminated successfully
 * 
 */
int main(int argc, char *argv[])
{
	int semSize = 0;
	int semID_read = 0;
	int semID_write = 0;
	
	int buffer = 0;
	
	int i = 0;

	int *pnShm = NULL;

	szCommand = argv[0];

	/* retrieve ringbuffer size from '-m' command parameter */
	/* or print out usage if nothing was declared */
	if ((semSize = getSemSize(argc, argv)) == -1)
	{
		printError("Usage: -m <ringbuffer-size>");
		exit(EXIT_FAILURE); 
	}
	
	/* get/create semaphore for reading from the ringbuffer */
	if ( (semID_read = getReadSemID(0)) == -1)
	{
			printError("Could not create semaphore");
			rmRessources(ERROR);
			exit(EXIT_FAILURE);
	}

	/* get/create semaphore for writing to the ringbuffer */
	if ( (semID_write = getWriteSemID(semSize)) == -1)
	{
			printError("Could not create semaphore");
			rmRessources(ERROR);
			exit(EXIT_FAILURE);
	}

	/* get/create shared memory */
	if ((pnShm = getShm(semSize * sizeof(int), 0)) == NULL)
	{
			printError("Could not create shared memory");
			rmRessources(ERROR);
			exit(EXIT_FAILURE);
	}

	/* read characters from STDIN and try to get them into the ringbuffer */
	while((buffer = getchar()) != EOF)
	{
		/* Ask writing-semaphore to enter the critical region for writing to ringbuffer */ 
		while(P(semID_write) == -1)
		{
			/* if P() returns -1 it could be an error or just a SIGNAL, so check this first */
			if(errno != EINTR)
			{
				/* nope, its an error. */ 
				printError("Could not write semaphore");
				rmRessources(ERROR);
				exit(EXIT_FAILURE);
			}
		}
		/* entering critical region HERE */

		/* write that character to the ring buffer */
		pnShm[i] = buffer;

		/* modify ringbuffer writing index */
		i++;
		i %= semSize;

		/* release that ring buffer cell for reading */
		if(V(semID_read) == -1)
		{
			printError("Could not read semaphore");
			rmRessources(ERROR);
			exit(EXIT_FAILURE);
		}
	}

	/* Write EOF into shared Memory */
	while(P(semID_write) == -1)
	{
		if(errno != EINTR)
		{
			printError("Could not write semaphore");
			rmRessources(ERROR);
			exit(EXIT_FAILURE);
		}
	}
	
	pnShm[i] = EOF;

	if(V(semID_read) == -1)
	{
		printError("Could not read semaphore");
		rmRessources(ERROR);
		exit(EXIT_FAILURE);
	}
	
	/* tidy up and exit */
	rmRessources(SENDER);
	exit( EXIT_SUCCESS );
}

/*
 * =================================================================== eof ==
 */

