/**
 * @mainpage Betriebsysteme Excercise 3: Shared Memory and Semaphore
 *
 * A sender writes broadcast to a shared memory which is read by the receiver.
 *
 * This work is an excercise for our study works on operating systems 
 */

/**
 * @file commons.h
 * Betriebsysteme Beispiel 3 - common library for maintaining semaphores and a shared memory (ring buffer).
 *
 * @author Stammgruppe 7
 * @author Matthias Heger-Koenig <matthias.hegerkoenig@technikum-wien.at> Matrikelnummer: 0910258029
 * @author Sebastian Vogel       <sebastian.vogel@technikum-wien.at>      Matrikelnummer: 0910258067
 * @author Juergen Zornig        <juergen.zornig@technikum-wien.at>       Matrikelnummer: 0910258047
 * @date 2010/05/10
 *
 * @version $Revision: 32 $
 *
 * @todo nothing to do.
 *
 * URL: $HeadURL$
 *
 * Last Modified: $Author: sebastian $
 */


#ifndef COMMONS_H

#define COMMONS_H

/*
 * --------------------------------------------------------------- defines --
 */

#define ERROR -1

#define SENDER 1
#define EMPFAENGER 2

/*
 * --------------------------------------------------------------- globals --
 */


/*
 * global for the program name
 */
extern const char *szCommand;

/*
 * -------------------------------------------------------------- functions --
 */

void printError(const char *szMessage);

int getSemSize(int argc, char * const argv[]); 

int getReadSemID(int semSize);

int getWriteSemID(int semSize);

int *getShm(int shmSize, int permFlag);

void rmRessources(int mode);


#endif

/*
 * =================================================================== eof ==
 */

