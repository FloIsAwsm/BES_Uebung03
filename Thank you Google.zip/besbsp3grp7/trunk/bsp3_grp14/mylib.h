/**
* @file mylib
* Betriebsysteme mylib Functions Header File.
* Uebung 3
*
* @author Christian Pipp 			<christian.pipp@technikum-wien.at>
* @author Bernhard Hoechtl 			<bernhard.hoechtl@technikum-wien.at>
* @author Roman Leonhartsberger 	<roman.leonhartsberger@technikum-wien.at>
* @date 2010/04/30
*
* @version $Revision: 1.0 $
*
* Last Modified: 2010/05/23
*/

#ifndef LIB_RINGBUFFER_H
#define LIB_RINGBUFFER_H

/*
* -------------------------------- includes --
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <errno.h>
#include <strings.h>
#include <limits.h>
#include <sem182.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
/*
* --------------------------------------------------------------- defines --
*/
#define STANDARD_RINGBUFFER_KEY 177177344

/*
* -------------------------------------------------------------- typedefs --
*/

/*
* --------------------------------------------------------------- globals --
*/


/*
* ------------------------------------------------------------- functions --
*/
int createRingBuffer(key_t key, long bufferSize);
int writeRingBuffer(key_t key, int data);
int readRingBuffer(key_t key, int *pData);
int removeRingBuffer(key_t key);
void usage(void);
void printErr(int error, char *pDescription);
long getSizeOfRingBuffer(int argc, char **argv);


#endif /* for library ringbuffer */
/*
* --------------------------------------------------------------------------
*/
