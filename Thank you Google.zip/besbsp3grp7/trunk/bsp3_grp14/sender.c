/**
* @file sender.c
* Betriebsysteme sender Functions Source File.
* Uebung 3
*
* @author Christian Pipp 			<christian.pipp@technikum-wien.at>
* @author Bernhard Hoechtl 			<bernhard.hoechtl@technikum-wien.at>
* @author Roman Leonhartsberger 	<roman.leonhartsberger@technikum-wien.at>
* @date 2010/04/30
*
* @version $Revision: 1.0 $
*
* Last Modified: 2010/06/04
*/



/*
* -------------------------------- includes --
*/
#include "mylib.h"

/*
* --------------------------------------------------------------- defines --
*/

/*
* -------------------------------------------------------------- typedefs --
*/

/*
* --------------------------------------------------------------- globals --
*/
static char *pPrgName = NULL;

/*
* ------------------------------------------------------------- functions --
*/

/*
* --------------------------------------------------------------------------
*/

/**
*
* \brief The main of the sender function
*
* \param argc count of arguments
* \param argv array of values in command line
*
* \return EXIT_SUCCESS or EXIT_FAILURE if successful or not
* \retval EXIT_SUCESSS if successful
* \retval EXIT_FAILURE if an error occured
*
*/

int main(int argc, char **argv)
{
	long sizeOfRingbuffer = 0;
	int tempChar = 0;

	/* save program name in a global var */
	pPrgName = argv[0];

	/* look for the size of ringbuffer */
	sizeOfRingbuffer = getSizeOfRingBuffer(argc, argv);

	/* if failure exit */
	if(sizeOfRingbuffer == EXIT_FAILURE)
		exit(EXIT_FAILURE);

	/*
	 * create your semaphore and shared memory for processing the data
	 */
	if(createRingBuffer(STANDARD_RINGBUFFER_KEY, sizeOfRingbuffer))
	{
		printErr(errno, "could not create the ringbuffer");
		removeRingBuffer(STANDARD_RINGBUFFER_KEY);
		return EXIT_FAILURE;
	}

	/*
	 * write stdin to ringbuffer
	 */
	while((tempChar = fgetc(stdin)) != EOF)
	{
		if(writeRingBuffer(STANDARD_RINGBUFFER_KEY, tempChar))
		{
			printErr(errno, "could not write to ringbuffer");
			removeRingBuffer(STANDARD_RINGBUFFER_KEY);
			return EXIT_FAILURE;
		}

	}

	/*
	* ### FB: siehe Artikel "Things to avoid in C, fflush(STDIN)" http://www.gidnetwork.com/b-57.html
	*/
	/* flushing stdin */
	if(fflush(stdin) != 0)
	{
		printErr(errno, "fflush() failed in sender");
		return EXIT_FAILURE;
	}

	/*
	 * write an eof for the receiver
	 * so he knows that input had finished
	 */

	if(writeRingBuffer(STANDARD_RINGBUFFER_KEY, EOF))
	{
		printErr(errno, "could not write EOF to ringbuffer");
		removeRingBuffer(STANDARD_RINGBUFFER_KEY);
		return EXIT_FAILURE;
	}

	/*
	 * info: semaphore und shared memory will be removed from receiver
	 */

	return EXIT_SUCCESS;
}


