/**
* @file receiver.c
* Betriebsysteme receiver Functions Source File.
* Uebung 3
*
* @author Christian Pipp 			<christian.pipp@technikum-wien.at>
* @author Bernhard Hoechtl 			<bernhard.hoechtl@technikum-wien.at>
* @author Roman Leonhartsberger 	<roman.leonhartsberger@technikum-wien.at>
* @date 2010/04/30
*
* @version $Revision: 1.0 $
*
* Last Modified:  $Author: christian $
*/



/*
* -------------------------------- includes --
*/
#include "mylib.h"

/*
* --------------------------------------------------------------- defines --
*/

/*
* -------------------------------------------------------------- typedefs --
*/

/*
* --------------------------------------------------------------- globals --
*/
static char *pPrgName = NULL;

/*
* ------------------------------------------------------------- functions --
*/

/*
* --------------------------------------------------------------------------
*/

/**
*
* \brief The main of the receiver function
*
* \param argc count of arguments
* \param argv array of values in command line
*
* \return EXIT_SUCCESS or EXIT_FAILURE if successful or not
* \retval EXIT_SUCESSS if successful
* \retval EXIT_FAILURE if an error occured
*
*/

int main (int argc, char **argv)
{
	long sizeOfRingbuffer;
	int tempChar;


	/* save program name in a global var */
	pPrgName = argv[0];

	/* look for the size of ringbuffer */
	sizeOfRingbuffer = getSizeOfRingBuffer(argc, argv);

	/* if failure exit */
	if(sizeOfRingbuffer == EXIT_FAILURE)
			exit(EXIT_FAILURE);

	/*
	 * create your semaphore and shared memory for processing the data
	 */
	if(createRingBuffer(STANDARD_RINGBUFFER_KEY, sizeOfRingbuffer))
	{
		printErr(errno, "cannot create the ringbuffer");
		removeRingBuffer(STANDARD_RINGBUFFER_KEY);
		return EXIT_FAILURE;
	}

	/*
	 * read from ringbuffer
     	 */
	if(readRingBuffer(STANDARD_RINGBUFFER_KEY, &tempChar))
		{
			printErr(errno, "cannot read from ringbuffer");
			removeRingBuffer(STANDARD_RINGBUFFER_KEY);
			return EXIT_FAILURE;
		}

	while(tempChar != EOF)
	{
			printf("%c", (char)tempChar);

			if(readRingBuffer(STANDARD_RINGBUFFER_KEY, &tempChar))
			{
				printErr(errno, "cannot read from ringbuffer");
				removeRingBuffer(STANDARD_RINGBUFFER_KEY);
				return EXIT_FAILURE;
			}

	}

	/*
	 * remove the ringbuffer of the receiver
	 * (semaphore and shared memory)
	 */
	if(removeRingBuffer(STANDARD_RINGBUFFER_KEY))
	{
			printErr(errno, "Something went wrong during closing the ringbuffer of receiver");
			return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

