/**
* @file mylib
* Betriebsysteme mylib Functions Source File.
* Uebung 3
*
* @author Christian Pipp 			<christian.pipp@technikum-wien.at>
* @author Bernhard Hoechtl 			<bernhard.hoechtl@technikum-wien.at>
* @author Roman Leonhartsberger 	<roman.leonhartsberger@technikum-wien.at>
* @date 2010/04/30
*
* @version $Revision: 1.0 $
*
* Last Modified: 2010/05/23
*/



/*
* -------------------------------- includes --
*/
#include "mylib.h"

/*
* --------------------------------------------------------------- defines --
*/
#define RB_CREATE_PERMISSION 0660

/*
* -------------------------------------------------------------- typedefs --
*/

/*
* --------------------------------------------------------------- globals --
*/
int curBufIndex;
long curBufSize;

/*
* ------------------------------------------------------------- functions --
*/

/*
* --------------------------------------------------------------------------
*/

/**
*
* \brief creates two semaphores with the given key and bufferSize
* \brief and also get the shared memory for the required size
*
* \param key: unique key for semaphore
* \param bufferSize: wanted size of ringbuffer
*
* \return failure or sucess
* \retval 0 if everything is ok
* \retval not equal 0 if something went wrong
*
*/
int createRingBuffer(key_t key, long bufferSize)
{
	/* for semaphore */
	int semRead = -1;
	int semWrite = -1;

	/* for shared memory */
	int shmId = -1;

	if(bufferSize <= 0)
	{
		errno = EINVAL;
		return errno;
	}

	/*
	 * try to init the semaphore
	 * and create two of them for read and write
	 */
	/*
	 * ### FB: Zuerst 2x hintereinander Syscall, und dann erst viel sp�ter die Fehlerabfrage?
	 *          - einerseits un�bersichtlich
	 *          - andererseits �berschreibt ein Sys-Call evtl. die errno des anderen -> Fehler ist somit de facto nicht behandelt
	 */
	semRead  = seminit(key+1,RB_CREATE_PERMISSION, 0);
	semWrite = seminit(key+2,RB_CREATE_PERMISSION, bufferSize);

	/*
	 * if the semaphore already exist try to grab him
	 */
	if(semRead == -1)
	{
		semRead = semgrab(key+1);
	}

	if(semWrite == -1)
	{
		semWrite = semgrab(key+2);
	}

	/* if not possible to grab them return an error */
	if(semRead == -1 || semWrite == -1)
	{
		/*
		 * ### FB: Hier wieder eine errno zu setzen, bzw. eigentlich zu raten ist nicht zul�ssig
		 */
		errno = EBADR;
		return errno;
	}

	/*
	 * create the shared memory and check if shared memory already exists
	 */
	if((shmId = shmget(key,	sizeof(int) * bufferSize, RB_CREATE_PERMISSION | IPC_CREAT | IPC_EXCL)) == -1)
		/* if it is so the the shared memory already exists */
	{
		if((shmId = shmget(key, sizeof(int) * bufferSize, RB_CREATE_PERMISSION)) == -1)
		{
			return errno;
			/* errno comes from shmget() */
		}

	}

	/* set the current ringbuffer index to a global var of mylib */
	curBufIndex = 0;

	/* set the size of ringbuffer elements to a global var of mylib */
	curBufSize = bufferSize;

	return 0;
}

/**
*
* \brief write to the ringbuffer
*
* \param key: unique key for semaphore
* \param data: the data to write
*
* \return errno or 0
* \retval errno when something went wrong
* \retval 0 if everything ok
*
*/
int writeRingBuffer(key_t key, int data)
{
	int shmId = -1;
	int *pBuf;

	/*
	 * ### FB: Durch die anschlie�ende Fehlerbehandlung grunds�tzlich ok, aber mutig. 
	 *         Man muss sich schlie�lich sicher sein, dass dieser Key "Bereich" zur Verf�gung steht
	 */
	int semRead = semgrab(key+1);
	int semWrite = semgrab(key+2);

	if(semRead == -1 || semWrite == -1)
	{
		errno = EBADR;
		return errno;
	}

	/* get shared memory */
	if((shmId = shmget(key, 1, RB_CREATE_PERMISSION)) == -1)
	{
		return errno;
	}

	/* attach shared memory */
	if((pBuf = shmat(shmId, NULL, 0)) == (int *)-1)
	{
		return errno;
	}

	/* decrease */
	while(P(semWrite) == -1)
	{
		/* this is no error only a signal */
		if(errno != EINTR)
		{
		  return errno;
		}
	}

	/* TRANSMIT DATA */
	pBuf[curBufIndex] = data;
	curBufIndex = (curBufIndex + 1) % curBufSize;

	/* increment */
	if(V(semRead) == -1)
	{
		errno = EFAULT;
		return errno;
	}

	/* deattach shared memory */
	if(shmdt(pBuf) == -1)
	{
		return errno;
	}


	return 0;
}

/**
*
* \brief read from ringbuffer
*
* \param key: unique key for Semaphore
* \param pData: the pointer in which the data will be pushed
*
* \return 0 or 1 for failure or success
* \retval 0 when everything is ok


 * ### FB: stimmt ja nicht, es wird errno zur�ckgegeben, oder?

* \retval 1 an error occured
*
*/
int readRingBuffer(key_t key, int *pData)
{
	int shmId = -1;
	int *pBuf;

	int semRead = semgrab(key+1);
	int semWrite = semgrab(key+2);

	if(semRead == -1 || semWrite == -1)
	{
		errno = EBADR;
		return errno;
	}

	/* get shared memory */
	if((shmId = shmget(key, 1, RB_CREATE_PERMISSION)) == -1)
	{
		return errno;
	}

	/*
		 * ### FB: Attach und Deattach bei JEDEM gelesenen Character...(betr�chtlicher Overhead)
		 */
	/* attach shared memory */
	if((pBuf = shmat(shmId, NULL, 0)) == (int *)-1)
	{
		return errno;
	}

	/* decrease */
	while(P(semRead) == -1	)
	{
		/* this is no error only a signal */
		if(errno != EINTR)
		{
			return errno;
		}
	}

	/* TRANSMIT DATA */
	*pData = pBuf[curBufIndex];
	curBufIndex = (curBufIndex + 1) % curBufSize;

	/* increase */
	if(V(semWrite) == -1)
	{
		errno = EFAULT;
		return errno;
	}
	

	/* deattach shared memory */
	if(shmdt(pBuf) == -1)
	{
		return errno;
	}

	return 0;
}

/**
*
* \brief removes the semaphore and shared memory
*
* \param key: unique key for Semaphore
*
* \return 0 or 1 for failure or success
* \retval 0 when everything is ok
* \retval 1 an error occured
*
*/
int removeRingBuffer(key_t key)
{
	int shmId = -1;
	int retval = 0;

	int semRead = semgrab(key+1);
	int semWrite = semgrab(key+2);

	if(semRead != -1)
	{
		/* remove semaphore */
		if(semrm(semRead) == -1)
		{
			errno = EFAULT;
			/*
		 * ### FB: nicht einheitlicher Return Wert
		 */
			retval = 1;
		}
	}
	else
	{
		errno = EBADR;
		retval = 1;
	}

	if(semWrite != -1)
	{
		if(semrm(semWrite) == -1)
		{
			errno = EFAULT;
			retval = 1;
		}
	}
	else
	{
		errno = EBADR;
		retval = 1;
	}

	/* get shared memory id */
	if((shmId = shmget(key,1,RB_CREATE_PERMISSION)) == -1)
	{
		retval = 1;
	}
	else
	{
		/* remove shared memory */
		if(shmctl(shmId, IPC_RMID, NULL) == -1)
		{
			retval = 1;
		}
	}
	return retval;
}

/**
*
* \brief print the usage message of the prg
* \brief use the global var pPrgName to output the program name
*
* \return nothing
*
*/
void usage(void)
{
	printf("usage: sender/receiver -m <ringbuffer size>\n");
	printf("<ringbuffer size> have to be larger than 0 !!\n\n");
}


/**
*
* \brief print error message to stderr
* \brief with short description
* \brief and strerror() of errno
*
* \return nothing
*
*/

void printErr(int error, char *pDescription)
{
	fprintf(stderr,"Error -> %s (error: %d ... %s)\n", pDescription, error, strerror(error));
}

/**
*
* \brief get the size, which ist used as buffer for the ringbuffer
*
* \return int wanted size of ringbuffer
*
*/

long getSizeOfRingBuffer(int argc, char **argv)
{
	int c;
	long size = 0;

	if(argv == NULL)
		return EXIT_FAILURE;

	while((c = getopt(argc, argv, "m:")) != -1) {
		switch(c)
		{
			case 'm':
				size = strtol(optarg, NULL, 10);
				if(size == LONG_MIN || size == LONG_MAX || size == 0)
				{
					 if(errno == ERANGE)
				     {
						 usage();
						 return EXIT_FAILURE;
				     }
			    }
				break;
			case '?':
				usage();
				return EXIT_FAILURE;
			default:
				return EXIT_FAILURE;
				break;
		}
	}

	if(optind != argc)
	{
		usage();
		return EXIT_FAILURE;
	}

	return size;
}
